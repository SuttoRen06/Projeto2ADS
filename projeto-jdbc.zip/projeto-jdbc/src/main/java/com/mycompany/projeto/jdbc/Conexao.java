/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projeto.jdbc;

import org.apache.commons.dbcp2.BasicDataSource;
/**
 *
 * @author lucas.martins
 */
public class Conexao {
    private BasicDataSource dataSource;

    public Conexao(){
        dataSource = new BasicDataSource();
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setUrl("jdbc:sqlserver://bl4ck.database.windows.net:1433;database=Whisper;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");
        dataSource.setUsername("bandtec");
        dataSource.setPassword("Upnow@2019");
    }
    
    public BasicDataSource getDataSource() {
        System.out.println(dataSource);
        return dataSource;
    }
    
    
}