/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projeto.jdbc;

import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author lucas.martins
 */
public class ProgramaLeitura {
    public static void main(String[] args) {
        Conexao dadosConexao = new Conexao();
        
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dadosConexao.getDataSource());
        
        List lista = jdbcTemplate.queryForList("insert into employee values (1,'alex',1220)");
        System.out.println("Consulta: "+lista);
        
    }
}
