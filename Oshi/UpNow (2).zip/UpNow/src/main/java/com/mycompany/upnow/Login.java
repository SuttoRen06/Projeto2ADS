/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.upnow;

/**
 *
 * @author lucas.martins
 */
public class Login {
    private final String userName = "admin";
    private final String userPassword = "admin";
    
    public Boolean Logar(String user, String password){
        
        if(userName.equals(user)&&userPassword.equals(password)){
            
            return true;
        
        }else{
        
            return false;
        
        }
    }
}
